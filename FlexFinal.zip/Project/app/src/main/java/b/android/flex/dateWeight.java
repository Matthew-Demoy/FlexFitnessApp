package b.android.flex;
//Date and weight! probably coulve just used a pair but hey WHATEVA!
public class dateWeight {
    String mDate;
    long mWeight;

    dateWeight(){
        mDate = null;
        mWeight = -1;
    }

    dateWeight(String date, long weight)
    {
        mDate = date;
        mWeight = weight;
    }


}
